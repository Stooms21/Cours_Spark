import unittest
from pyspark.sql import SparkSession
from src.fr.hymaia.exo2.spark_clean_job import adult_clients, join_zip, ajout_departement

class SparkCleanJobTest(unittest.TestCase):

    spark = SparkSession.builder.appName('unittest').getOrCreate()

    def test_adult_clients(self):
        # Given
        data = [("1", 17), ("2", 18), ("3", 19)]
        df = self.spark.createDataFrame(data, ["id", "age"])

        # When
        result = adult_clients(df)

        expected_data = [("2", 18), ("3", 19)]
        expected_df = self.spark.createDataFrame(expected_data, ["id", "age"])

        # Then
        self.assertEqual(result.collect(), expected_df.collect())

    def test_join_zip(self):
        # Prepare test data
        data_clients = [("1", "1000"), ("2", "2000")]
        df_clients = self.spark.createDataFrame(data_clients, ["id", "zip"])
        data_zip_code = [("1000", "info1"), ("2000", "info2")]
        df_zip_code = self.spark.createDataFrame(data_zip_code, ["zip", "info"])

        # Call join_zip function
        result = join_zip(df_clients, df_zip_code)

        # Prepare expected data
        expected_data = [("1", "1000", "info1"), ("2", "2000", "info2")]
        expected_df = self.spark.createDataFrame(expected_data, ["id", "zip", "info"])

        # Assert the result
        self.assertEqual(result.collect(), expected_df.collect())

    def test_ajout_departement(self):
        # Prepare test data
        data = [("1", "20000"), ("2", "20190"), ("3", "75000")]
        df = self.spark.createDataFrame(data, ["id", "zip"])

        # Call ajout_departement function
        result = ajout_departement(df)

        # Prepare expected data
        expected_data = [("1", "20000", "2B"), ("2", "20190", "2A"), ("3", "75000", "75")]
        expected_df = self.spark.createDataFrame(expected_data, ["id", "zip", "departement"])

        # Assert the result
        self.assertEqual(result.collect(), expected_df.collect())

if __name__ == "__main__":
    unittest.main()